package org.cvtc.shapes;

public interface Renderer 
{
	public void render();
}
