package org.cvtc.shapes;

public class ShapeFactory 
{
	// Dialog
	Dialog dialog = new MessageBox();
	
	// Accessors for Dialog
	private void setDialog(Dialog dialog)
	{
		this.dialog = dialog;
	}
	
	private Dialog getDialog()
	{
		return dialog;
	}
	
	public ShapeFactory(Dialog dialog)
	{
		
	}
	
	public Shape make(ShapeType type, float depthRadius, float height, float width)
	{
		if(type == null)
		{
			return null;
		}
		
		if(type.equals(ShapeType.Cuboid))
		{
			return new Cuboid(null, width, height, depthRadius);
		} 
		else if(type.equals(ShapeType.Cylinder))
		{
			return new Cylinder(null, height, depthRadius);
		}
		else if(type.equals(ShapeType.Sphere))
		{
			return new Sphere(null, depthRadius);
		}
		
		return null;
	}
	
}
