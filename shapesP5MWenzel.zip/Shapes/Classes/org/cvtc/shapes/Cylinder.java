package org.cvtc.shapes;

/**
 * @author Mitch
 *
 */
public class Cylinder extends Shape implements Renderer
{

	// Variable declaration
	private float radius = 0;
	private float height = 0;
	
	MessageBox messageCylin = new MessageBox();
	

	// Getters and Setters
	@Override
	void getMessageBox() 
	{
	}

	@Override
	float getSurfaceArea() 
	{
		return 0;
	}

	@Override
	float getVolume() 
	{
		return 0;
	}
	
	public float getRadius()
	{
		return radius;
	}
	
	public void setRadius(float radius)
	{
		this.radius = radius;
		
		if (radius < 0) 
		{
	        throw new IllegalArgumentException("Radius cannot be negative.");
		}
	}
	
	public float getHeight()
	{
		return height;
	}
	
	public void setHeight(float height)
	{
		this.height = height;
		
		if (height < 0) 
		{
	        throw new IllegalArgumentException("Height cannot be negative.");
		}
	}
	
	// Constructor for cylinder object	
	public Cylinder(Dialog messageBox, float radius, float height) 
	{
		setRadius(radius);
		
		setHeight(height);
	}

	// Surface Area calculation method. Inherited from abstract in Shapes.java
	@Override
	public float surfaceArea() 
	{
		float surfaceArea = (float) ((2 * Math.PI * radius * height) + (2 * Math.PI * Math.pow(radius, 2)));
		
		return surfaceArea;
	}

	// Volume calculation method. Inherited from abstract in Shapes.java
	@Override
	public float volume() 
	{
		float volume = (float) (Math.PI * Math.pow(radius, 2) * height);
		
		return volume;
	}

	// Render method for message boxes. Inherited from interface Renderer
	@Override
	public void render() 
	{
		messageCylin.show("The surface area of the cylinder is " + surfaceArea() + "\n" +
						  "The volume of the cylinder is " + volume(), "Cylinder");
	}

	@Override
	void draw() 
	{
		System.out.println("TESTSphere");
		
		render();
		
	}

}
