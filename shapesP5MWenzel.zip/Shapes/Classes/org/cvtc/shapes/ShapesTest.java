/**
 * 
 */
package org.cvtc.shapes;
import java.util.Scanner;

/**
 * @author Mitch
 *
 */
public class ShapesTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		// Creating/initializing shape variables for user input
		String userShape;

		// "unused" variable acts as placeholder for shapeFactory arguments
		float unused = 0;
		
		// Cube variables
		float userCubeWidth = 0;
		float userCubeHeight = 0;
		float userCubeDepth = 0;
		
		// Cylinder variables
		float userCylinderRadius = 0;
		float userCylinderHeight = 0;
		
		// Sphere variables
		float userSphereRadius = 0;
		
		
		// Instantiating new Scanner object
		Scanner userInput = new Scanner(System.in);
		

		// Instantiating Factory
		ShapeFactory shapeFactory = new ShapeFactory(null);
		
		
		// Prompting for type of shape and values
		System.out.print("Enter 'cuboid' or 'cylinder' or 'sphere': ");
		userShape = userInput.nextLine();
				
		if(userShape.equalsIgnoreCase("cuboid"))
		{
			System.out.println("Enter the height of the cuboid:");
			userCubeHeight = userInput.nextFloat();
			
			System.out.println("Enter the width of the cuboid:");
			userCubeWidth = userInput.nextFloat();
			
			System.out.println("Enter the depth of the cuboid:");
			userCubeDepth = userInput.nextFloat();
			

			Shape shape1 = shapeFactory.make(ShapeType.Cuboid, userCubeWidth, userCubeHeight, userCubeDepth);
			shape1.draw();
			
		}
		else if(userShape.equalsIgnoreCase("sphere"))
		{
			System.out.println("Enter the radius of the sphere:");
			userSphereRadius = userInput.nextFloat();
			
			
			Shape shape3 = shapeFactory.make(ShapeType.Sphere, userSphereRadius, unused, unused);
			shape3.draw();
		}
		else if(userShape.equalsIgnoreCase("cylinder"))
		{
			System.out.println("Enter the height of the cylinder:");
			userCylinderHeight = userInput.nextFloat();
			
			System.out.println("Enter the radius of the cylinder:");
			userCylinderRadius = userInput.nextFloat();
			
			
			Shape shape2 = shapeFactory.make(ShapeType.Cylinder, userCylinderHeight, userCylinderRadius, unused);
			shape2.draw();
		}
		
	
		// Closing resource for userInput
		userInput.close();
	}

}
