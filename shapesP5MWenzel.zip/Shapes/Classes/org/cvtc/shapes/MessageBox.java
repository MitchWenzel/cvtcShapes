package org.cvtc.shapes;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class MessageBox implements Dialog 
{

	@Override
	public int show(String message, String title) 
	{
		JFrame frame = new JFrame("Show Message Dialog");
		
		JOptionPane.showMessageDialog(frame, message, title, JOptionPane.PLAIN_MESSAGE);
		
		return 0;
	}

}
