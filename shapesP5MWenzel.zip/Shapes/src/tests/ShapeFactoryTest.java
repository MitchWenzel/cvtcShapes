package tests;

import static org.junit.Assert.*;

import org.cvtc.shapes.ShapeFactory;
import org.cvtc.shapes.ShapeType;
import org.junit.Test;

public class ShapeFactoryTest 
{

	ShapeFactory facTest = new ShapeFactory(null);

	Object TestCube = facTest.make(ShapeType.Cuboid, 5, 5, 5);
	Object TestCylin = facTest.make(ShapeType.Cylinder, 5, 5, 0);
	Object TestSphere = facTest.make(ShapeType.Sphere, 5, 0, 0);
	
	@Test
	public void testMake() 
	{
		assertNotNull(TestCube);
		assertNotNull(TestSphere);
		assertNotNull(TestCylin);
		
		assertNotSame(TestCube, TestSphere);
		assertNotSame(TestCube, TestCylin);
		
		assertNotSame(TestSphere, TestCylin);
		assertNotSame(TestSphere, TestCube);
		
		assertNotSame(TestCylin, TestSphere);
		assertNotSame(TestCylin, TestCube);
	}
	
}