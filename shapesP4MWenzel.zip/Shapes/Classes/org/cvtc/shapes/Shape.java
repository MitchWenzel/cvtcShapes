/**
 * 
 */
package org.cvtc.shapes;

/**
 * @author Mitch
 *
 */
public abstract class Shape 
{
	// Abstract methods for surface area/volume calculation and message boxes
	abstract float surfaceArea();
	
	abstract float volume();
	
	// Message Box
	Dialog messageBox;
	
	abstract void getMessageBox();
	protected void setMessageBox(Dialog messageBox) 
	{
		
	}
	
	public Shape()
	{
		System.out.println("Shape");
	}
	
	abstract float getSurfaceArea();
	abstract float getVolume();
}
