/**
 * 
 */
package org.cvtc.shapes;

/**
 * @author Mitch
 *
 */
public class Sphere extends Shape implements Renderer
{

	private float radius = 0;
	
	MessageBox messageSphe = new MessageBox();
	
	// Getters and Setters
	@Override
	void getMessageBox() 
	{
	}

	@Override
	float getSurfaceArea() 
	{
		return 0;
	}

	@Override
	float getVolume() 
	{
		return 0;
	}
	
	public float getRadius()
	{
		return radius;
	}
	
	public void setRadius(float radius)
	{
		this.radius = radius;

		if (radius < 0) 
		{
	        throw new IllegalArgumentException("Radius cannot be negative.");
		}
	}
	
	// Constructor for sphere object
	public Sphere(Dialog messageBox, float radius) 
	{
		setRadius(radius);
	}

	// Surface Area calculation method. Inherited from abstract in Shapes.java
	@Override
	public float surfaceArea() 
	{
		float surfaceArea = (float) (4 * Math.PI * Math.pow(radius, 2));
		
		return surfaceArea;
	}

	// Volume calculation method. Inherited from abstract in Shapes.java
	@Override
	public float volume() 
	{
		float volume = (float) (4 * Math.PI * (Math.pow(radius, 3) / 3));
		
		return volume;
	}

	// Render method for message boxes. Inherited from interface Renderer
	@Override
	public void render() 
	{
		messageSphe.show("The surface area of the sphere is " + surfaceArea() + "\n" +
				 		 "The volume of the sphere is " + volume(), "Sphere");

	}

}
