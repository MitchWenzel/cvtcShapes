/**
 * 
 */
package org.cvtc.shapes;
import java.util.Scanner;

/**
 * @author Mitch
 *
 */
public class ShapesTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		// Creating cube variables for user input
		float userCubeWidth;
		float userCubeHeight;
		float userCubeDepth;
		
		// Creating cylinder variables for user input
		float userCylinderRadius;
		float userCylinderHeight;
		
		// Creating sphere variables for user input
		float userSphereRadius;
		
		
		// Instantiating Shape objects
		Cuboid userCuboidResult = new Cuboid(null, 0, 0, 0);
		Cylinder userCylinResult = new Cylinder (null, 0, 0);
		Sphere userSpheResult = new Sphere (null, 0);
		
		
		// Instantiating new Scanner object
		Scanner userInput = new Scanner(System.in);
		
		
		// Prompting for user input for cube
		System.out.print("Enter the width of the cube: ");
		userCubeWidth = userInput.nextFloat();
		userCuboidResult.setWidth(userCubeWidth);
		
		System.out.print("Enter the height of the cube: ");
		userCubeHeight = userInput.nextFloat();
		userCuboidResult.setHeight(userCubeHeight);
		
		System.out.print("Enter the depth of the cube: ");
		userCubeDepth = userInput.nextFloat();
		userCuboidResult.setDepth(userCubeDepth);
		
		
		// Prompting for user input for cylinder
		System.out.print("Enter the radius of the cylinder: ");
		userCylinderRadius = userInput.nextFloat();
		userCylinResult.setRadius(userCylinderRadius);
		
		System.out.print("Enter the height of the cylinder: ");
		userCylinderHeight = userInput.nextFloat();
		userCylinResult.setHeight(userCylinderHeight);
		
		
		// Prompting for user input for sphere
		System.out.print("Enter the radius of the sphere: ");
		userSphereRadius = userInput.nextFloat();
		userSpheResult.setRadius(userSphereRadius);
		
		
		// Printing cube results of user input
		userCuboidResult.render();
		
		// Printing cylinder results of user input
		userCylinResult.render();
		
		// Printing sphere results of user input
		userSpheResult.render();
		
		
		// Closing resource for userInput
		userInput.close();
	}

}
